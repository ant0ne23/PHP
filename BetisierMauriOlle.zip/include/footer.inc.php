
<div id="footer">
Le bétisier de l'IUT à votre service, depuis novembre 2018
<br />
    © IUT du Limousin  DUT Informatique année 2 

</div>
</body>
</html>