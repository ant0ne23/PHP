
	<h1>Supprimer des personnes enregistrées</h1>
	<?php
    $pdo=new Mypdo();
    $personneManager = new PersonneManager($pdo);
    $personnes=$personneManager->getAllPersonnes();
?>
    <h1>Supprimer des personnes enregistrées</h1>
    <label for="departement">Nom :</label>
    <SELECT name="departement" size="1">
        <?php
        foreach ($personnes as $pers){ ?>
            <OPTION>
        <?php  echo $pers->getPerNom();
     } ?>
    </SELECT>
    </br>
     <input type="submit" name="submit">
