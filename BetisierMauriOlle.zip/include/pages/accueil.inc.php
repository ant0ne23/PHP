<img class="centreImage" src="image/logo.gif" alt="Covoiturage IUT" title="Covoiturage IUT Limousin"/>
	