<?php
$db=new Mypdo();
$personneManager=new PersonneManager($db);
$etudiantManager = new EtudiantManager($db);
$salarieManager=new SalarieManager($db);

if(empty($_POST['categorie'])){
 ?>
<h1>Ajouter une personne</h1>
<form method="post" action="index.php?page=1">
<label for="nom">Nom :</label>
<input type="texte" required="required" id="nom" name="nom" size="15">
</br>
<label for="prenom">Prenom :</label>
<input type="texte" required="required" id="prenom" name="prenom" size="15">
</br>
<label for="tel">Telephone :</label>
<input type="texte" required="required" id="tel" name="tel" size="15">
</br>
<label for="mail">Mail :</label>
<input type="texte" required="required" id="mail" name="mail" size="15">
</br>
<label for="login">Login :</label>
<input type="texte" required="required" id="login" name="login" size="15">
</br>
<label for="mdp">Mot de Passe :</label>
<input type="password" required="required" id="mdp" name="mdp" size="15">
</br>
<label for="categorie">Catégorie</label>
<input type="radio" name="categorie" value="etudiant">Etudiant
<input type="radio" name="categorie" value="personnel">Personnel
</br>
<input type="submit" name="submit">
</br>
</form>

<?php
}
else {
      $_SESSION['personne'] = serialize(new Personne(array ('per_nom' => $_POST['nom'],
      'per_prenom' => $_POST['prenom'],
      'per_tel' => $_POST['tel'],
      'per_mail' => $_POST['mail'],
      'per_login' => $_POST['login'],
      'per_pwd' => $_POST['mdp'])));
    if ($_POST['categorie']=="etudiant")
    {
        $departement=$etudiantManager->get_liste_departement();
        $division=$etudiantManager->get_liste_annees();
        ?>
				<h1>Ajouter un Etudiant</h1>
				<form method="post" action="index.php?page=1">
					<label for="departement">Departement :</label>
					<SELECT name="departement" size="1">
            <?php
            foreach ($departement as $dep) {
              ?><OPTION><?php echo $dep->getDep();
            }
             ?>
					</SELECT></br>
					<label for="division">Division :</label>
					<SELECT name="division" size="1">
            <?php
            foreach ($division as $div) {
              ?><OPTION><?php echo $div->getDiv();
            }
             ?>
					</SELECT>
          <input type="submit" name="submit">
				</form>
				<?php
    }
    if ($_POST['categorie']=="personnel")
    {
        $fonction=$salarieManager->get_liste_fonctions();
				?>
				<h1>Ajouter un Salarie</h1>
        <form method="post" action="index.php?page=1">
  				<label for="tel">Telephone professionnel :</label>
  				<input type="texte" required="required" id="tel" name="tel" size="15">
  				</br>
  				<label for="fonction">Fonction</label>
  				<SELECT name="fonction" size="1">
            <?php
            foreach ($fonction as $fon) {
              ?><OPTION><?php echo $fon->getFon();
            }
             ?>
  				</SELECT>
          </br>
          <input type="submit" name="submit">
        </form>
				<?php
    }
    else{
      if(!isempty($_POST("fonction"))){
        $personneManager->addPersonne(unserialize($_SESSION['salarie']));
        $salarie = serialize(new Personne(array ('sal_telprof' => $_POST['tel'],
        'fon_num' => $_POST['fonction'];
        $salarieManager->addSalarie(unserialize($_SESSION['salarie']));
      }
      if(!isempty($_POST("division"))){
        $personneManager->addPersonne(unserialize($_SESSION['salarie']));
        $etudiant = serialize(new Personne(array ('div_num' => $_POST['division'],
        'fonction' => $_POST['prenom'];
        $etudiantManager->addEtudiant(unserialize($_SESSION['etudiant']));
      }
    }
}
 ?>
