Structure de base pour l'application Bétisier de l'IUT du Limousin en PHP <br />
<br />

Le fichier config.inc.php contient les paramètres pour la base MySQL <br /> </br>
Vous devez compléter ce travail pour obtenir les écrans demandés.  <br />
Je souhaite un code bien documenté et clair<br />
Merci de respecter la date limte de remise du travail !!!! <br /> <br />
<b> ⊂(◉‿◉)つ <b> <br />