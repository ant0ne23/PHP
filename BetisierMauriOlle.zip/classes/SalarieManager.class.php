<?php
class SalarieManager{
  public function __construct($db){
    $this->db=$db;
  }

  public function detailSalarie($perNum){
    $sql = 'SELECT p.per_nom, p.per_prenom, p.per_mail, p.per_tel, s.sal_telprof, f.fon_libelle FROM PERSONNE p JOIN SALARIE s ON p.per_num = s.per_num JOIN FONCTION f ON s.fon_num = f.fon_num  WHERE p.per_num ='.$perNum;

    $requete=$this->db->prepare($sql);
    $requete->execute();

    $detailSal = $requete->fetch(PDO::FETCH_OBJ);
    $sal = new Salarie($detailSal);
    $requete->closeCursor();

    return $sal;
  }

  public function get_liste_fonctions(){
      $sql = "SELECT fon_libelle FROM FONCTION";

      $requete = $this->db->prepare($sql);
      $requete->execute();

      while ($fon_lib = $requete->fetch(PDO::FETCH_OBJ))
              $listefonction[] = new Salarie($fon_lib);

      $requete->closeCursor();
      return $listefonction;
  }
}
?>
