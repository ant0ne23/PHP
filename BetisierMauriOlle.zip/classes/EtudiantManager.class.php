<?php
class EtudiantManager{
  public function __construct($db){
    $this->db=$db;
  }

  public function detailEtu($perNum){
    $sql = 'SELECT p.per_nom, p.per_prenom, p.per_mail, p.per_tel, d.dep_nom, v.vil_nom FROM PERSONNE p JOIN ETUDIANT e ON p.per_num = e.per_num JOIN DEPARTEMENT d ON e.dep_num = d.dep_num JOIN VILLE v ON d.vil_num = v.vil_num  WHERE p.per_num ='.$perNum;

    $requete = $this->db->prepare($sql);
    $requete->execute();


    $detailEtu = $requete->fetch(PDO::FETCH_OBJ);
    $etu = new Etudiant($detailEtu);
    $requete->closeCursor();

    return $etu;
  }

  public function get_liste_departement(){
      $sql = "SELECT dep_nom FROM DEPARTEMENT";

      $requete = $this->db->prepare($sql);
      $requete->execute();

      while ($dep_nom = $requete->fetch(PDO::FETCH_OBJ))
              $listedepartements[] = new Etudiant($dep_nom);

      $requete->closeCursor();
      return $listedepartements;
  }

  public function get_liste_annees(){
      $sql = "SELECT div_nom FROM DIVISION";

      $requete = $this->db->prepare($sql);
      $requete->execute();

      while ($div_nom = $requete->fetch(PDO::FETCH_OBJ))
              $listedivision[] = new Etudiant($div_nom);

      $requete->closeCursor();
      return $listedivision;
  }
}
 ?>
